package com.kigarama.sacco.controller;

import com.kigarama.sacco.model.ChatMessage;
import com.kigarama.sacco.model.User;
import com.kigarama.sacco.repository.UserRepository;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.ChatService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/chat")
public class ChatController {

    private static final List<String> ALLOWED_EXTENSIONS = List.of("pdf", "doc", "docx", "jpg", "jpeg", "png", "gif");

    private final ChatService chatService;
    private final UserRepository userRepository;

    @Value("${sacco.uploads.dir}")
    private String uploadsDir;

    public ChatController(ChatService chatService, UserRepository userRepository) {
        this.chatService = chatService;
        this.userRepository = userRepository;
    }

    /** Everyone in the system except the current user — anyone can message anyone. */
    @PreAuthorize("isAuthenticated()")
    @GetMapping("/contacts")
    public ResponseEntity<?> contacts(@AuthenticationPrincipal CustomUserDetails principal) {
        List<User> contacts = userRepository.findAll().stream()
                .filter(u -> u.isActive() && !u.getId().equals(principal.getId()))
                .sorted(Comparator.comparing((User u) -> u.getRole().name()).thenComparing(User::getFullName))
                .collect(Collectors.toList());
        Map<Long, Long> unreadCounts = chatService.unreadCountsBySender(principal.getId());
        return ResponseEntity.ok(contacts.stream().map(u -> toContactPayload(u, unreadCounts)).collect(Collectors.toList()));
    }

    @PreAuthorize("isAuthenticated()")
    @GetMapping("/conversation/{otherUserId}")
    public ResponseEntity<?> conversation(@PathVariable Long otherUserId,
                                           @AuthenticationPrincipal CustomUserDetails principal) {
        List<ChatMessage> messages = chatService.conversation(principal.getId(), otherUserId);
        chatService.markConversationRead(principal.getId(), otherUserId);
        return ResponseEntity.ok(messages.stream().map(this::toMessagePayload).collect(Collectors.toList()));
    }

    @PreAuthorize("isAuthenticated()")
    @PostMapping("/send")
    public ResponseEntity<?> send(@RequestParam Long receiverId,
                                   @RequestParam(required = false) String message,
                                   @RequestParam(required = false) MultipartFile file,
                                   @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            String attachmentUrl = null;
            String attachmentName = null;
            if (file != null && !file.isEmpty()) {
                String original = file.getOriginalFilename() != null ? file.getOriginalFilename() : "attachment";
                String ext = original.contains(".") ? original.substring(original.lastIndexOf('.') + 1).toLowerCase() : "";
                if (!ALLOWED_EXTENSIONS.contains(ext)) {
                    return ResponseEntity.badRequest().body(Map.of("error",
                            "Only PDF, Word documents and image files (jpg, png, gif) may be attached."));
                }
                Path dir = Path.of(uploadsDir, "chat");
                Files.createDirectories(dir);
                String storedName = UUID.randomUUID() + "." + ext;
                Path target = dir.resolve(storedName);
                try (InputStream in = file.getInputStream(); OutputStream out = Files.newOutputStream(target)) {
                    in.transferTo(out);
                }
                attachmentUrl = "/uploads/chat/" + storedName;
                attachmentName = original;
            }

            ChatMessage saved = chatService.sendMessage(principal.getId(), receiverId, message, attachmentUrl, attachmentName);
            return ResponseEntity.ok(toMessagePayload(saved));
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Failed to store attachment."));
        }
    }

    private Map<String, Object> toContactPayload(User u, Map<Long, Long> unreadCounts) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", u.getId());
        map.put("fullName", u.getFullName());
        map.put("username", u.getUsername());
        map.put("role", u.getRole().name());
        map.put("profilePicUrl", u.getProfilePicUrl());
        map.put("unreadCount", unreadCounts.getOrDefault(u.getId(), 0L));
        return map;
    }

    private Map<String, Object> toMessagePayload(ChatMessage m) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", m.getId());
        map.put("senderId", m.getSender().getId());
        map.put("senderName", m.getSender().getFullName());
        map.put("receiverId", m.getReceiver().getId());
        map.put("message", m.getMessage());
        map.put("attachmentUrl", m.getAttachmentUrl());
        map.put("attachmentName", m.getAttachmentName());
        map.put("read", m.isRead());
        map.put("timestamp", m.getTimestamp());
        return map;
    }
}
