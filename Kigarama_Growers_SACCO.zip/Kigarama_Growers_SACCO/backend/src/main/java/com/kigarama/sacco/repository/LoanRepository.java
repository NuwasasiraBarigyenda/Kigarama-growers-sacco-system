package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.Loan;
import com.kigarama.sacco.model.LoanStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface LoanRepository extends JpaRepository<Loan, Long> {

    @Query("select l from Loan l join fetch l.member where l.member.id = :memberId order by l.appliedAt desc")
    List<Loan> findByMemberIdOrderByAppliedAtDesc(Long memberId);

    @Query("select l from Loan l join fetch l.member order by l.appliedAt desc")
    List<Loan> findAllOrderByAppliedAtDesc();

    @Query("select l from Loan l join fetch l.member where l.status = :status order by l.appliedAt desc")
    List<Loan> findByStatusOrderByAppliedAtDesc(LoanStatus status);
}
