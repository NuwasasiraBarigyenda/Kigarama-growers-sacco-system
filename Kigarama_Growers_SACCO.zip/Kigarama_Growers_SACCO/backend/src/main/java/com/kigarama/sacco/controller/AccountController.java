package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.AmountRequest;
import com.kigarama.sacco.dto.PinRequest;
import com.kigarama.sacco.model.Account;
import com.kigarama.sacco.repository.TransactionRepository;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.AccountService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/account")
public class AccountController {

    private final AccountService accountService;
    private final TransactionRepository transactionRepository;

    public AccountController(AccountService accountService, TransactionRepository transactionRepository) {
        this.accountService = accountService;
        this.transactionRepository = transactionRepository;
    }

    /** Returns account metadata WITHOUT the balance — balance requires a separate PIN-verified call. */
    @PreAuthorize("hasRole('MEMBER')")
    @GetMapping("/me")
    public ResponseEntity<?> myAccount(@AuthenticationPrincipal CustomUserDetails principal) {
        try {
            Account account = accountService.getByUserId(principal.getId());
            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("accountNumber", account.getAccountNumber());
            payload.put("createdAt", account.getCreatedAt());
            return ResponseEntity.ok(payload);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** Members must submit their secret PIN to reveal the balance. */
    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/balance")
    public ResponseEntity<?> revealBalance(@RequestBody PinRequest request,
                                            @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            var balance = accountService.revealBalance(principal.getId(), request.getPin());
            return ResponseEntity.ok(Map.of("balance", balance));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/change-pin")
    public ResponseEntity<?> changePin(@RequestBody Map<String, String> body,
                                        @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            accountService.changePin(principal.getId(), body.get("currentPin"), body.get("newPin"));
            return ResponseEntity.ok(Map.of("message", "PIN updated successfully."));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasRole('MEMBER')")
    @GetMapping("/transactions")
    public ResponseEntity<?> myTransactions(@AuthenticationPrincipal CustomUserDetails principal) {
        Account account = accountService.getByUserId(principal.getId());
        return ResponseEntity.ok(transactionRepository.findByAccountIdOrderByTimestampDesc(account.getId()));
    }

    // ---------------- Cashier operations ----------------

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/lookup/{accountNumber}")
    public ResponseEntity<?> lookup(@PathVariable String accountNumber) {
        try {
            Account account = accountService.getByAccountNumber(accountNumber);
            Map<String, Object> payload = new LinkedHashMap<>();
            payload.put("id", account.getId());
            payload.put("accountNumber", account.getAccountNumber());
            payload.put("memberName", account.getUser().getFullName());
            payload.put("memberUsername", account.getUser().getUsername());
            payload.put("balance", account.getBalance());
            return ResponseEntity.ok(payload);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/deposit")
    public ResponseEntity<?> deposit(@RequestBody AmountRequest request,
                                      @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            Long accountId = resolveAccountId(request);
            return ResponseEntity.ok(accountService.deposit(accountId, request.getAmount(), principal.getUsername(), request.getDescription()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/withdraw")
    public ResponseEntity<?> withdraw(@RequestBody AmountRequest request,
                                       @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            Long accountId = resolveAccountId(request);
            return ResponseEntity.ok(accountService.withdraw(accountId, request.getAmount(), principal.getUsername(), request.getDescription()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/recent-transactions")
    public ResponseEntity<?> recentTransactions() {
        return ResponseEntity.ok(transactionRepository.findTop100ByOrderByTimestampDesc());
    }

    // ---------------- Member self-service ----------------
    // Members can initiate their own deposits and withdrawals. Deposits need no PIN
    // (adding funds carries no risk to the member); withdrawals require the secret
    // SACCO PIN since they remove funds from the account.

    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/self-deposit")
    public ResponseEntity<?> selfDeposit(@RequestBody AmountRequest request,
                                          @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            Account account = accountService.getByUserId(principal.getId());
            return ResponseEntity.ok(accountService.deposit(account.getId(), request.getAmount(),
                    principal.getUsername() + " (self)", request.getDescription() != null ? request.getDescription() : "Member-initiated deposit"));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/self-withdraw")
    public ResponseEntity<?> selfWithdraw(@RequestBody Map<String, Object> body,
                                           @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            String pin = String.valueOf(body.get("pin"));
            accountService.revealBalance(principal.getId(), pin); // throws if PIN wrong; also confirms identity
            Account account = accountService.getByUserId(principal.getId());
            java.math.BigDecimal amount = new java.math.BigDecimal(String.valueOf(body.get("amount")));
            String description = body.get("description") != null ? String.valueOf(body.get("description")) : "Member-initiated withdrawal";
            return ResponseEntity.ok(accountService.withdraw(account.getId(), amount, principal.getUsername() + " (self)", description));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        }
    }

    private Long resolveAccountId(AmountRequest request) {
        if (request.getAccountId() != null) return request.getAccountId();
        if (request.getAccountNumber() != null && !request.getAccountNumber().isBlank()) {
            return accountService.getByAccountNumber(request.getAccountNumber()).getId();
        }
        throw new IllegalArgumentException("An account ID or account number is required.");
    }
}
