package com.kigarama.sacco.dto;

import java.math.BigDecimal;

public class PriceUpdateRequest {
    private BigDecimal pricePerKg;      // for coffee
    private BigDecimal small;
    private BigDecimal medium;
    private BigDecimal large;
    private String note;

    public BigDecimal getPricePerKg() { return pricePerKg; }
    public void setPricePerKg(BigDecimal pricePerKg) { this.pricePerKg = pricePerKg; }
    public BigDecimal getSmall() { return small; }
    public void setSmall(BigDecimal small) { this.small = small; }
    public BigDecimal getMedium() { return medium; }
    public void setMedium(BigDecimal medium) { this.medium = medium; }
    public BigDecimal getLarge() { return large; }
    public void setLarge(BigDecimal large) { this.large = large; }
    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}
