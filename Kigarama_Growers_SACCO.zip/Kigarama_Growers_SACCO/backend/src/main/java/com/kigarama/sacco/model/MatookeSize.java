package com.kigarama.sacco.model;

public enum MatookeSize {
    SMALL,
    MEDIUM,
    LARGE
}
