package com.kigarama.sacco.model;

public enum LoanStatus {
    PENDING,
    APPROVED,
    REJECTED,
    DISBURSED,
    CLOSED
}
