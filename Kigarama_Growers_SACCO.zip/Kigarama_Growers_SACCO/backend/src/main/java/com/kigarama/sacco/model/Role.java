package com.kigarama.sacco.model;

public enum Role {
    SUPER_ADMIN,
    ADMIN,
    CASHIER,
    RECEPTIONIST,
    MEMBER
}
