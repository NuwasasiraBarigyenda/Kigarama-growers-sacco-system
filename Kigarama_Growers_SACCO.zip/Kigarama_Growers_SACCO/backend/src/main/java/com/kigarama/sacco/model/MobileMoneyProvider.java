package com.kigarama.sacco.model;

public enum MobileMoneyProvider {
    MTN_MOMO,
    AIRTEL_MONEY
}
