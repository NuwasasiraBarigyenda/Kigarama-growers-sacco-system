package com.kigarama.sacco.model;

public enum TransactionType {
    DEPOSIT,
    WITHDRAWAL,
    COFFEE_SALE_CREDIT,
    MATOOKE_SALE_CREDIT,
    MOBILE_MONEY_DEPOSIT,
    LOAN_DISBURSEMENT,
    LOAN_REPAYMENT
}
