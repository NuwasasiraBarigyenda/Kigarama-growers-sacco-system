package com.kigarama.sacco.dto;

import java.math.BigDecimal;

public class CoffeeLogRequest {
    private Long memberId;
    private String memberUsername;
    private BigDecimal kilograms;

    public Long getMemberId() { return memberId; }
    public void setMemberId(Long memberId) { this.memberId = memberId; }
    public String getMemberUsername() { return memberUsername; }
    public void setMemberUsername(String memberUsername) { this.memberUsername = memberUsername; }
    public BigDecimal getKilograms() { return kilograms; }
    public void setKilograms(BigDecimal kilograms) { this.kilograms = kilograms; }
}
