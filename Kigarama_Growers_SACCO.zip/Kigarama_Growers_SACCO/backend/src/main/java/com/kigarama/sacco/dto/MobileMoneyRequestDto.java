package com.kigarama.sacco.dto;

import com.kigarama.sacco.model.MobileMoneyProvider;
import java.math.BigDecimal;

public class MobileMoneyRequestDto {
    private MobileMoneyProvider provider;
    private String phoneNumber;
    private BigDecimal amount;
    private String reference;

    public MobileMoneyProvider getProvider() { return provider; }
    public void setProvider(MobileMoneyProvider provider) { this.provider = provider; }
    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }
    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }
}
