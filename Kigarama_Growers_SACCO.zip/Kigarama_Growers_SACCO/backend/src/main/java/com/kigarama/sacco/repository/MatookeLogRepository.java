package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.MatookeLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MatookeLogRepository extends JpaRepository<MatookeLog, Long> {

    @Query("select m from MatookeLog m join fetch m.member where m.member.id = :memberId order by m.recordedAt desc")
    List<MatookeLog> findByMemberIdOrderByRecordedAtDesc(Long memberId);

    @Query("select m from MatookeLog m join fetch m.member order by m.recordedAt desc")
    List<MatookeLog> findTop50ByOrderByRecordedAtDesc(org.springframework.data.domain.Pageable pageable);

    default List<MatookeLog> findTop50ByOrderByRecordedAtDesc() {
        return findTop50ByOrderByRecordedAtDesc(org.springframework.data.domain.PageRequest.of(0, 50));
    }
}
