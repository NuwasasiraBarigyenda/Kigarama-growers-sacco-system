package com.kigarama.sacco.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "matooke_logs")
public class MatookeLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", nullable = false)
    private User member;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private MatookeSize size;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal pricePerBunchAtSale;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal totalValue;

    @Column(length = 60)
    private String recordedBy;

    @Column(nullable = false)
    private LocalDateTime recordedAt = LocalDateTime.now();

    @Column(nullable = false)
    private boolean creditedToAccount = true;

    public MatookeLog() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getMember() { return member; }
    public void setMember(User member) { this.member = member; }

    public MatookeSize getSize() { return size; }
    public void setSize(MatookeSize size) { this.size = size; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public BigDecimal getPricePerBunchAtSale() { return pricePerBunchAtSale; }
    public void setPricePerBunchAtSale(BigDecimal pricePerBunchAtSale) { this.pricePerBunchAtSale = pricePerBunchAtSale; }

    public BigDecimal getTotalValue() { return totalValue; }
    public void setTotalValue(BigDecimal totalValue) { this.totalValue = totalValue; }

    public String getRecordedBy() { return recordedBy; }
    public void setRecordedBy(String recordedBy) { this.recordedBy = recordedBy; }

    public LocalDateTime getRecordedAt() { return recordedAt; }
    public void setRecordedAt(LocalDateTime recordedAt) { this.recordedAt = recordedAt; }

    public boolean isCreditedToAccount() { return creditedToAccount; }
    public void setCreditedToAccount(boolean creditedToAccount) { this.creditedToAccount = creditedToAccount; }
}
