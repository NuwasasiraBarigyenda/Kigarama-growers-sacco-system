package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.CoffeePrice;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CoffeePriceRepository extends JpaRepository<CoffeePrice, Long> {
    Optional<CoffeePrice> findFirstByOrderByEffectiveAtDesc();
    List<CoffeePrice> findTop30ByOrderByEffectiveAtDesc();
}
