package com.kigarama.sacco.controller;

import com.kigarama.sacco.model.ChatMessage;
import com.kigarama.sacco.repository.ChatMessageRepository;
import com.kigarama.sacco.security.CustomUserDetails;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final ChatMessageRepository chatMessageRepository;

    public NotificationController(ChatMessageRepository chatMessageRepository) {
        this.chatMessageRepository = chatMessageRepository;
    }

    /** Powers the notification bell: unread message count + a short preview list. */
    @GetMapping("/summary")
    public ResponseEntity<?> summary(@AuthenticationPrincipal CustomUserDetails principal) {
        long unreadCount = chatMessageRepository.countByReceiverIdAndIsReadFalse(principal.getId());
        List<ChatMessage> unread = chatMessageRepository.findUnreadWithSender(principal.getId());

        List<Map<String, Object>> previews = unread.stream().limit(8).map(m -> {
            Map<String, Object> p = new LinkedHashMap<>();
            p.put("id", m.getId());
            p.put("fromUserId", m.getSender().getId());
            p.put("fromName", m.getSender().getFullName());
            p.put("message", m.getMessage());
            p.put("timestamp", m.getTimestamp());
            return p;
        }).collect(Collectors.toList());

        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("unreadCount", unreadCount);
        payload.put("previews", previews);
        return ResponseEntity.ok(payload);
    }
}
