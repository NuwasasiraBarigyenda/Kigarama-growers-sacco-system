package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.MatookePrice;
import com.kigarama.sacco.model.MatookeSize;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface MatookePriceRepository extends JpaRepository<MatookePrice, Long> {
    Optional<MatookePrice> findFirstBySizeOrderByEffectiveAtDesc(MatookeSize size);
}
