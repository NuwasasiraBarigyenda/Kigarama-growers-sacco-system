package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.ChangePasswordRequest;
import com.kigarama.sacco.dto.UpdateProfileRequest;
import com.kigarama.sacco.model.User;
import com.kigarama.sacco.repository.UserRepository;
import com.kigarama.sacco.security.CustomUserDetails;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

    private static final List<String> ALLOWED_IMAGE_EXTENSIONS = List.of("jpg", "jpeg", "png", "gif", "webp");

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${sacco.uploads.dir}")
    private String uploadsDir;

    public ProfileController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @GetMapping("/me")
    public ResponseEntity<?> myProfile(@AuthenticationPrincipal CustomUserDetails principal) {
        return ResponseEntity.ok(toPayload(principal.getUser()));
    }

    @PutMapping("/me")
    public ResponseEntity<?> updateProfile(@RequestBody UpdateProfileRequest request,
                                            @AuthenticationPrincipal CustomUserDetails principal) {
        User user = userRepository.findById(principal.getId())
                .orElseThrow(() -> new IllegalArgumentException("User not found."));

        if (request.getFullName() != null && !request.getFullName().isBlank()) {
            user.setFullName(request.getFullName().trim());
        }
        if (request.getPhone() != null) {
            user.setPhone(request.getPhone().trim());
        }
        if (request.getEmail() != null && !request.getEmail().isBlank()
                && !request.getEmail().trim().equalsIgnoreCase(user.getEmail())) {
            String newEmail = request.getEmail().trim();
            if (userRepository.existsByEmailIgnoreCase(newEmail)) {
                return ResponseEntity.badRequest().body(Map.of("error", "That email is already in use by another account."));
            }
            user.setEmail(newEmail);
        }
        userRepository.save(user);
        return ResponseEntity.ok(toPayload(user));
    }

    @PostMapping("/change-password")
    public ResponseEntity<?> changePassword(@RequestBody ChangePasswordRequest request,
                                             @AuthenticationPrincipal CustomUserDetails principal) {
        User user = userRepository.findById(principal.getId())
                .orElseThrow(() -> new IllegalArgumentException("User not found."));
        if (!passwordEncoder.matches(request.getCurrentPassword(), user.getPassword())) {
            return ResponseEntity.status(403).body(Map.of("error", "Current password is incorrect."));
        }
        if (request.getNewPassword() == null || request.getNewPassword().length() < 6) {
            return ResponseEntity.badRequest().body(Map.of("error", "New password must be at least 6 characters."));
        }
        user.setPassword(passwordEncoder.encode(request.getNewPassword()));
        userRepository.save(user);
        return ResponseEntity.ok(Map.of("message", "Password updated successfully."));
    }

    @PostMapping("/picture")
    public ResponseEntity<?> uploadPicture(@RequestParam MultipartFile file,
                                            @AuthenticationPrincipal CustomUserDetails principal) {
        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No file provided."));
        }
        String original = file.getOriginalFilename() != null ? file.getOriginalFilename() : "photo";
        String ext = original.contains(".") ? original.substring(original.lastIndexOf('.') + 1).toLowerCase() : "";
        if (!ALLOWED_IMAGE_EXTENSIONS.contains(ext)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Only image files (jpg, png, gif, webp) are allowed."));
        }
        try {
            Path dir = Path.of(uploadsDir, "profile");
            Files.createDirectories(dir);
            String storedName = "user" + principal.getId() + "-" + UUID.randomUUID() + "." + ext;
            Path target = dir.resolve(storedName);
            try (InputStream in = file.getInputStream(); OutputStream out = Files.newOutputStream(target)) {
                in.transferTo(out);
            }
            String url = "/uploads/profile/" + storedName;

            User user = userRepository.findById(principal.getId())
                    .orElseThrow(() -> new IllegalArgumentException("User not found."));
            user.setProfilePicUrl(url);
            userRepository.save(user);

            return ResponseEntity.ok(Map.of("profilePicUrl", url));
        } catch (IOException e) {
            return ResponseEntity.internalServerError().body(Map.of("error", "Failed to save profile picture."));
        }
    }

    private Map<String, Object> toPayload(User user) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", user.getId());
        map.put("username", user.getUsername());
        map.put("fullName", user.getFullName());
        map.put("phone", user.getPhone());
        map.put("email", user.getEmail());
        map.put("role", user.getRole().name());
        map.put("profilePicUrl", user.getProfilePicUrl());
        return map;
    }
}
