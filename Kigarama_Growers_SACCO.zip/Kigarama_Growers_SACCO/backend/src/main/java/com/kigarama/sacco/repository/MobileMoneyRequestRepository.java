package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.MobileMoneyRequest;
import com.kigarama.sacco.model.MobileMoneyStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface MobileMoneyRequestRepository extends JpaRepository<MobileMoneyRequest, Long> {

    @Query("select m from MobileMoneyRequest m join fetch m.member where m.member.id = :memberId order by m.requestedAt desc")
    List<MobileMoneyRequest> findByMemberIdOrderByRequestedAtDesc(Long memberId);

    @Query("select m from MobileMoneyRequest m join fetch m.member where m.status = :status order by m.requestedAt desc")
    List<MobileMoneyRequest> findByStatusOrderByRequestedAtDesc(MobileMoneyStatus status);

    @Query("select m from MobileMoneyRequest m join fetch m.member order by m.requestedAt desc")
    List<MobileMoneyRequest> findAllOrderByRequestedAtDesc();
}
