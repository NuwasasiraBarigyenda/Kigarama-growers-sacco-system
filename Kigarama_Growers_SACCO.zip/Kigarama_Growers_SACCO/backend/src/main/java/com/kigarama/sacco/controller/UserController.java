package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.CreateUserRequest;
import com.kigarama.sacco.dto.CreateUserResult;
import com.kigarama.sacco.model.Role;
import com.kigarama.sacco.model.User;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.UserService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PostMapping
    public ResponseEntity<?> createUser(@Valid @RequestBody CreateUserRequest request,
                                         @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            CreateUserResult result = userService.createUser(request, principal.getUser().getRole(), principal.getUsername());
            Map<String, Object> payload = toPayload(result.getUser());
            // Shown once on screen as a fallback in case the welcome email doesn't arrive —
            // this is the only response that will ever contain the plaintext PIN.
            if (result.getPlainPin() != null) {
                payload.put("generatedPin", result.getPlainPin());
            }
            return ResponseEntity.ok(payload);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER','RECEPTIONIST')")
    @GetMapping
    public ResponseEntity<?> listUsers(@RequestParam(required = false) String role) {
        List<User> users = (role != null && !role.isBlank())
                ? userService.listByRole(Role.valueOf(role.trim().toUpperCase()))
                : userService.listAll();
        return ResponseEntity.ok(users.stream().map(this::toPayload).collect(Collectors.toList()));
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PutMapping("/{id}/status")
    public ResponseEntity<?> setStatus(@PathVariable Long id, @RequestParam boolean active) {
        try {
            User updated = userService.setActive(id, active);
            return ResponseEntity.ok(toPayload(updated));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private Map<String, Object> toPayload(User u) {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", u.getId());
        map.put("username", u.getUsername());
        map.put("fullName", u.getFullName());
        map.put("phone", u.getPhone());
        map.put("email", u.getEmail());
        map.put("profilePicUrl", u.getProfilePicUrl());
        map.put("role", u.getRole().name());
        map.put("active", u.isActive());
        map.put("createdAt", u.getCreatedAt());
        map.put("createdBy", u.getCreatedBy());
        return map;
    }
}
