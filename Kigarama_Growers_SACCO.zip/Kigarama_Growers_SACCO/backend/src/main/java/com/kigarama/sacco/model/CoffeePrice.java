package com.kigarama.sacco.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * A price-per-kilogram entry for coffee. New rows are inserted whenever the price
 * changes so the system keeps a full history of world-market fluctuations; the
 * most recent row (by effectiveAt) is always the active price.
 */
@Entity
@Table(name = "coffee_prices")
public class CoffeePrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal pricePerKg;

    @Column(nullable = false)
    private LocalDateTime effectiveAt = LocalDateTime.now();

    @Column(length = 60)
    private String setBy;

    @Column(length = 255)
    private String note;

    public CoffeePrice() {}

    public CoffeePrice(BigDecimal pricePerKg, String setBy, String note) {
        this.pricePerKg = pricePerKg;
        this.setBy = setBy;
        this.note = note;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public BigDecimal getPricePerKg() { return pricePerKg; }
    public void setPricePerKg(BigDecimal pricePerKg) { this.pricePerKg = pricePerKg; }

    public LocalDateTime getEffectiveAt() { return effectiveAt; }
    public void setEffectiveAt(LocalDateTime effectiveAt) { this.effectiveAt = effectiveAt; }

    public String getSetBy() { return setBy; }
    public void setSetBy(String setBy) { this.setBy = setBy; }

    public String getNote() { return note; }
    public void setNote(String note) { this.note = note; }
}
