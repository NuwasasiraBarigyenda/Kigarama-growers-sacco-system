package com.kigarama.sacco.service;

import com.kigarama.sacco.model.*;
import com.kigarama.sacco.repository.MobileMoneyRequestRepository;
import com.kigarama.sacco.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class MobileMoneyService {

    private final MobileMoneyRequestRepository requestRepository;
    private final UserRepository userRepository;
    private final AccountService accountService;

    public MobileMoneyService(MobileMoneyRequestRepository requestRepository, UserRepository userRepository,
                               AccountService accountService) {
        this.requestRepository = requestRepository;
        this.userRepository = userRepository;
        this.accountService = accountService;
    }

    @Transactional
    public MobileMoneyRequest submit(Long memberId, MobileMoneyProvider provider, String phoneNumber,
                                      BigDecimal amount, String reference) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
        if (phoneNumber == null || phoneNumber.isBlank()) {
            throw new IllegalArgumentException("A mobile money phone number is required.");
        }
        User member = userRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found."));

        MobileMoneyRequest request = new MobileMoneyRequest();
        request.setMember(member);
        request.setProvider(provider);
        request.setPhoneNumber(phoneNumber.trim());
        request.setAmount(amount);
        request.setReference(reference);
        request.setStatus(MobileMoneyStatus.PENDING);
        return requestRepository.save(request);
    }

    public List<MobileMoneyRequest> myRequests(Long memberId) {
        return requestRepository.findByMemberIdOrderByRequestedAtDesc(memberId);
    }

    public List<MobileMoneyRequest> pending() {
        return requestRepository.findByStatusOrderByRequestedAtDesc(MobileMoneyStatus.PENDING);
    }

    public List<MobileMoneyRequest> all() {
        return requestRepository.findAllOrderByRequestedAtDesc();
    }

    @Transactional
    public MobileMoneyRequest approve(Long requestId, String decidedBy) {
        MobileMoneyRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Request not found."));
        if (request.getStatus() != MobileMoneyStatus.PENDING) {
            throw new IllegalArgumentException("This request has already been decided.");
        }
        Account account = accountService.getByUserId(request.getMember().getId());
        accountService.credit(account, request.getAmount(), TransactionType.MOBILE_MONEY_DEPOSIT, decidedBy,
                "Mobile money deposit (" + request.getProvider() + ", " + request.getPhoneNumber() + ")"
                        + (request.getReference() != null ? " ref: " + request.getReference() : ""));

        request.setStatus(MobileMoneyStatus.APPROVED);
        request.setDecidedBy(decidedBy);
        request.setDecidedAt(LocalDateTime.now());
        return requestRepository.save(request);
    }

    @Transactional
    public MobileMoneyRequest reject(Long requestId, String decidedBy, String notes) {
        MobileMoneyRequest request = requestRepository.findById(requestId)
                .orElseThrow(() -> new IllegalArgumentException("Request not found."));
        if (request.getStatus() != MobileMoneyStatus.PENDING) {
            throw new IllegalArgumentException("This request has already been decided.");
        }
        request.setStatus(MobileMoneyStatus.REJECTED);
        request.setDecidedBy(decidedBy);
        request.setDecidedAt(LocalDateTime.now());
        request.setDecisionNotes(notes);
        return requestRepository.save(request);
    }
}
