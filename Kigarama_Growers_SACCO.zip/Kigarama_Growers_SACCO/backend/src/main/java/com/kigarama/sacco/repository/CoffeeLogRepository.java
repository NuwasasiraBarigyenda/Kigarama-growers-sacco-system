package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.CoffeeLog;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CoffeeLogRepository extends JpaRepository<CoffeeLog, Long> {

    @Query("select c from CoffeeLog c join fetch c.member where c.member.id = :memberId order by c.recordedAt desc")
    List<CoffeeLog> findByMemberIdOrderByRecordedAtDesc(Long memberId);

    @Query("select c from CoffeeLog c join fetch c.member order by c.recordedAt desc")
    List<CoffeeLog> findTop50ByOrderByRecordedAtDesc(org.springframework.data.domain.Pageable pageable);

    default List<CoffeeLog> findTop50ByOrderByRecordedAtDesc() {
        return findTop50ByOrderByRecordedAtDesc(org.springframework.data.domain.PageRequest.of(0, 50));
    }
}
