package com.kigarama.sacco.controller;

import com.kigarama.sacco.model.Role;
import com.kigarama.sacco.model.TransactionType;
import com.kigarama.sacco.repository.*;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    private final UserRepository userRepository;
    private final AccountRepository accountRepository;
    private final CoffeeLogRepository coffeeLogRepository;
    private final MatookeLogRepository matookeLogRepository;
    private final TransactionRepository transactionRepository;

    public DashboardController(UserRepository userRepository, AccountRepository accountRepository,
                                CoffeeLogRepository coffeeLogRepository, MatookeLogRepository matookeLogRepository,
                                TransactionRepository transactionRepository) {
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
        this.coffeeLogRepository = coffeeLogRepository;
        this.matookeLogRepository = matookeLogRepository;
        this.transactionRepository = transactionRepository;
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/summary")
    public ResponseEntity<?> summary() {
        Map<String, Object> summary = new LinkedHashMap<>();
        summary.put("totalMembers", userRepository.countByRole(Role.MEMBER));
        summary.put("totalCashiers", userRepository.countByRole(Role.CASHIER));
        summary.put("totalReceptionists", userRepository.countByRole(Role.RECEPTIONIST));
        summary.put("totalAdmins", userRepository.countByRole(Role.ADMIN));

        BigDecimal totalSavings = accountRepository.findAll().stream()
                .map(a -> a.getBalance())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        summary.put("totalSavingsHeld", totalSavings);

        BigDecimal totalCoffeeKg = coffeeLogRepository.findAll().stream()
                .map(c -> c.getKilograms())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        summary.put("totalCoffeeKg", totalCoffeeKg);

        int totalMatookeBunches = matookeLogRepository.findAll().stream()
                .mapToInt(m -> m.getQuantity())
                .sum();
        summary.put("totalMatookeBunches", totalMatookeBunches);

        BigDecimal totalDeposits = transactionRepository.findAll().stream()
                .filter(t -> t.getType() == TransactionType.DEPOSIT)
                .map(t -> t.getAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        summary.put("totalDeposits", totalDeposits);

        BigDecimal totalWithdrawals = transactionRepository.findAll().stream()
                .filter(t -> t.getType() == TransactionType.WITHDRAWAL)
                .map(t -> t.getAmount())
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        summary.put("totalWithdrawals", totalWithdrawals);

        return ResponseEntity.ok(summary);
    }
}
