package com.kigarama.sacco.model;

public enum MobileMoneyStatus {
    PENDING,
    APPROVED,
    REJECTED
}
