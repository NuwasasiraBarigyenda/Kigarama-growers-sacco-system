package com.kigarama.sacco.dto;

import com.kigarama.sacco.model.User;

/**
 * Internal result of creating a user — carries the plaintext PIN (members only) alongside the
 * saved User so the controller can show/email it once. The PIN itself is never persisted or
 * logged anywhere in plaintext beyond this one-time trip back to the creator.
 */
public class CreateUserResult {
    private final User user;
    private final String plainPin; // null for non-member roles

    public CreateUserResult(User user, String plainPin) {
        this.user = user;
        this.plainPin = plainPin;
    }

    public User getUser() { return user; }
    public String getPlainPin() { return plainPin; }
}
