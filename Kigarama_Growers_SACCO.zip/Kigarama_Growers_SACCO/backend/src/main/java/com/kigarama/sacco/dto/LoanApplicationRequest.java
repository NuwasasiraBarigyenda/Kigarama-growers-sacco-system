package com.kigarama.sacco.dto;

import java.math.BigDecimal;

public class LoanApplicationRequest {
    private BigDecimal amountRequested;
    private String purpose;

    public BigDecimal getAmountRequested() { return amountRequested; }
    public void setAmountRequested(BigDecimal amountRequested) { this.amountRequested = amountRequested; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
}
