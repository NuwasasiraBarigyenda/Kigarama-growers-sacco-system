package com.kigarama.sacco.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "matooke_prices")
public class MatookePrice {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 10)
    private MatookeSize size;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal pricePerBunch;

    @Column(nullable = false)
    private LocalDateTime effectiveAt = LocalDateTime.now();

    @Column(length = 60)
    private String setBy;

    public MatookePrice() {}

    public MatookePrice(MatookeSize size, BigDecimal pricePerBunch, String setBy) {
        this.size = size;
        this.pricePerBunch = pricePerBunch;
        this.setBy = setBy;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public MatookeSize getSize() { return size; }
    public void setSize(MatookeSize size) { this.size = size; }

    public BigDecimal getPricePerBunch() { return pricePerBunch; }
    public void setPricePerBunch(BigDecimal pricePerBunch) { this.pricePerBunch = pricePerBunch; }

    public LocalDateTime getEffectiveAt() { return effectiveAt; }
    public void setEffectiveAt(LocalDateTime effectiveAt) { this.effectiveAt = effectiveAt; }

    public String getSetBy() { return setBy; }
    public void setSetBy(String setBy) { this.setBy = setBy; }
}
