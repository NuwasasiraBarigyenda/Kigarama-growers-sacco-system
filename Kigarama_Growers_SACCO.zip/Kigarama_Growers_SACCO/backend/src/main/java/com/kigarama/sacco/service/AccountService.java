package com.kigarama.sacco.service;

import com.kigarama.sacco.model.Account;
import com.kigarama.sacco.model.Transaction;
import com.kigarama.sacco.model.TransactionType;
import com.kigarama.sacco.repository.AccountRepository;
import com.kigarama.sacco.repository.TransactionRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;

@Service
public class AccountService {

    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;
    private final PasswordEncoder passwordEncoder;

    public AccountService(AccountRepository accountRepository, TransactionRepository transactionRepository,
                           PasswordEncoder passwordEncoder) {
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public Account getByUserId(Long userId) {
        return accountRepository.findByUserId(userId)
                .orElseThrow(() -> new IllegalArgumentException("No savings account found for this user."));
    }

    public Account getByAccountNumber(String accountNumber) {
        return accountRepository.findByAccountNumber(accountNumber)
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));
    }

    public Account getById(Long id) {
        return accountRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Account not found."));
    }

    /**
     * Verifies the member's secret SACCO PIN before revealing the balance.
     * Throws if the PIN does not match.
     */
    public BigDecimal revealBalance(Long userId, String pin) {
        Account account = getByUserId(userId);
        if (!passwordEncoder.matches(pin, account.getPinHash())) {
            throw new IllegalArgumentException("Incorrect PIN.");
        }
        return account.getBalance();
    }

    @Transactional
    public void changePin(Long userId, String currentPin, String newPin) {
        Account account = getByUserId(userId);
        if (!passwordEncoder.matches(currentPin, account.getPinHash())) {
            throw new IllegalArgumentException("Current PIN is incorrect.");
        }
        account.setPinHash(passwordEncoder.encode(newPin));
        accountRepository.save(account);
    }

    @Transactional
    public Transaction deposit(Long accountId, BigDecimal amount, String performedBy, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Deposit amount must be greater than zero.");
        }
        Account account = getById(accountId);
        account.setBalance(account.getBalance().add(amount));
        accountRepository.save(account);
        return recordTransaction(account, TransactionType.DEPOSIT, amount, performedBy,
                description != null ? description : "Cash deposit");
    }

    @Transactional
    public Transaction withdraw(Long accountId, BigDecimal amount, String performedBy, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Withdrawal amount must be greater than zero.");
        }
        Account account = getById(accountId);
        if (account.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient balance for this withdrawal.");
        }
        account.setBalance(account.getBalance().subtract(amount));
        accountRepository.save(account);
        return recordTransaction(account, TransactionType.WITHDRAWAL, amount, performedBy,
                description != null ? description : "Cash withdrawal");
    }

    @Transactional
    public Transaction credit(Account account, BigDecimal amount, TransactionType type,
                               String performedBy, String description) {
        account.setBalance(account.getBalance().add(amount));
        accountRepository.save(account);
        return recordTransaction(account, type, amount, performedBy, description);
    }

    /** Debits an account for a reason other than a teller withdrawal (e.g. a loan repayment). */
    @Transactional
    public Transaction debit(Long accountId, BigDecimal amount, TransactionType type,
                              String performedBy, String description) {
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }
        Account account = getById(accountId);
        if (account.getBalance().compareTo(amount) < 0) {
            throw new IllegalArgumentException("Insufficient balance.");
        }
        account.setBalance(account.getBalance().subtract(amount));
        accountRepository.save(account);
        return recordTransaction(account, type, amount, performedBy, description);
    }

    private Transaction recordTransaction(Account account, TransactionType type, BigDecimal amount,
                                           String performedBy, String description) {
        Transaction tx = new Transaction();
        tx.setAccount(account);
        tx.setType(type);
        tx.setAmount(amount);
        tx.setBalanceAfter(account.getBalance());
        tx.setPerformedBy(performedBy);
        tx.setDescription(description);
        return transactionRepository.save(tx);
    }
}
