package com.kigarama.sacco.dto;

import jakarta.validation.constraints.NotBlank;

public class PinRequest {
    @NotBlank
    private String pin;

    public String getPin() { return pin; }
    public void setPin(String pin) { this.pin = pin; }
}
