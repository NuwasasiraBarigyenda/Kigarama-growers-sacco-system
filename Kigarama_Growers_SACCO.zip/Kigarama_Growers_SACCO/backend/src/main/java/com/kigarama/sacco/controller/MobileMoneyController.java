package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.MobileMoneyRequestDto;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.MobileMoneyService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/mobilemoney")
public class MobileMoneyController {

    private final MobileMoneyService mobileMoneyService;

    public MobileMoneyController(MobileMoneyService mobileMoneyService) {
        this.mobileMoneyService = mobileMoneyService;
    }

    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/request")
    public ResponseEntity<?> submit(@RequestBody MobileMoneyRequestDto request,
                                     @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            return ResponseEntity.ok(mobileMoneyService.submit(principal.getId(), request.getProvider(),
                    request.getPhoneNumber(), request.getAmount(), request.getReference()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasRole('MEMBER')")
    @GetMapping("/my")
    public ResponseEntity<?> myRequests(@AuthenticationPrincipal CustomUserDetails principal) {
        return ResponseEntity.ok(mobileMoneyService.myRequests(principal.getId()));
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/pending")
    public ResponseEntity<?> pending() {
        return ResponseEntity.ok(mobileMoneyService.pending());
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping
    public ResponseEntity<?> all() {
        return ResponseEntity.ok(mobileMoneyService.all());
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/{id}/approve")
    public ResponseEntity<?> approve(@PathVariable Long id, @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            return ResponseEntity.ok(mobileMoneyService.approve(id, principal.getUsername()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/{id}/reject")
    public ResponseEntity<?> reject(@PathVariable Long id, @RequestBody(required = false) Map<String, String> body,
                                     @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            String notes = body != null ? body.get("notes") : null;
            return ResponseEntity.ok(mobileMoneyService.reject(id, principal.getUsername(), notes));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
