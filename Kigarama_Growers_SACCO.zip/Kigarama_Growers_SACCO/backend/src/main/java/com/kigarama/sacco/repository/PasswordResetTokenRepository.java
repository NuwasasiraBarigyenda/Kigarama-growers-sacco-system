package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.PasswordResetToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Long> {

    @Query("select t from PasswordResetToken t join fetch t.user where t.user.id = :userId and t.code = :code " +
           "and t.used = false order by t.createdAt desc")
    List<PasswordResetToken> findValidCandidates(Long userId, String code);
}
