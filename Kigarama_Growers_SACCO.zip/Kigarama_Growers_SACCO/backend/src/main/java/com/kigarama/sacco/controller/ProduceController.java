package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.CoffeeLogRequest;
import com.kigarama.sacco.dto.MatookeLogRequest;
import com.kigarama.sacco.model.User;
import com.kigarama.sacco.repository.UserRepository;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.ProduceService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/produce")
public class ProduceController {

    private final ProduceService produceService;
    private final UserRepository userRepository;

    public ProduceController(ProduceService produceService, UserRepository userRepository) {
        this.produceService = produceService;
        this.userRepository = userRepository;
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/coffee")
    public ResponseEntity<?> logCoffee(@RequestBody CoffeeLogRequest request,
                                        @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            Long memberId = resolveMemberId(request.getMemberId(), request.getMemberUsername());
            return ResponseEntity.ok(produceService.logCoffeeIntake(memberId, request.getKilograms(), principal.getUsername()));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/matooke")
    public ResponseEntity<?> logMatooke(@RequestBody MatookeLogRequest request,
                                         @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            Long memberId = resolveMemberId(request.getMemberId(), request.getMemberUsername());
            return ResponseEntity.ok(produceService.logMatookeIntake(memberId, request.getSize(), request.getQuantity(), principal.getUsername()));
        } catch (IllegalArgumentException | IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/coffee/recent")
    public ResponseEntity<?> recentCoffee() {
        return ResponseEntity.ok(produceService.recentCoffeeLogs());
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/matooke/recent")
    public ResponseEntity<?> recentMatooke() {
        return ResponseEntity.ok(produceService.recentMatookeLogs());
    }

    @PreAuthorize("hasRole('MEMBER')")
    @GetMapping("/my-history")
    public ResponseEntity<?> myHistory(@AuthenticationPrincipal CustomUserDetails principal) {
        Long memberId = principal.getId();
        return ResponseEntity.ok(Map.of(
                "coffee", produceService.coffeeHistoryFor(memberId),
                "matooke", produceService.matookeHistoryFor(memberId)
        ));
    }

    private Long resolveMemberId(Long memberId, String username) {
        if (memberId != null) return memberId;
        if (username != null && !username.isBlank()) {
            User u = userRepository.findByUsernameIgnoreCase(username.trim())
                    .orElseThrow(() -> new IllegalArgumentException("Member username not found."));
            return u.getId();
        }
        throw new IllegalArgumentException("A member ID or username is required.");
    }
}
