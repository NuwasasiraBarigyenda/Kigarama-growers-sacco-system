package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.PriceUpdateRequest;
import com.kigarama.sacco.model.MatookeSize;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.ProduceService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/prices")
public class PriceController {

    private final ProduceService produceService;

    public PriceController(ProduceService produceService) {
        this.produceService = produceService;
    }

    /** Publicly viewable to any authenticated user (members need live prices). */
    @GetMapping("/current")
    public ResponseEntity<?> current() {
        Map<String, Object> payload = new LinkedHashMap<>();
        payload.put("coffeePerKg", produceService.getCurrentCoffeePrice().getPricePerKg());
        payload.put("coffeeUpdatedAt", produceService.getCurrentCoffeePrice().getEffectiveAt());
        Map<String, Object> matooke = new LinkedHashMap<>();
        for (MatookeSize size : MatookeSize.values()) {
            matooke.put(size.name(), produceService.getCurrentMatookePrice(size).getPricePerBunch());
        }
        payload.put("matooke", matooke);
        return ResponseEntity.ok(payload);
    }

    @GetMapping("/coffee/history")
    public ResponseEntity<?> coffeeHistory() {
        return ResponseEntity.ok(produceService.getCoffeePriceHistory());
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PostMapping("/coffee")
    public ResponseEntity<?> updateCoffeePrice(@RequestBody PriceUpdateRequest request,
                                                @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            return ResponseEntity.ok(produceService.updateCoffeePrice(request.getPricePerKg(), principal.getUsername(), request.getNote()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PostMapping("/matooke")
    public ResponseEntity<?> updateMatookePrices(@RequestBody PriceUpdateRequest request,
                                                  @AuthenticationPrincipal CustomUserDetails principal) {
        produceService.updateMatookePrices(request.getSmall(), request.getMedium(), request.getLarge(), principal.getUsername());
        return ResponseEntity.ok(Map.of("message", "Matooke prices updated."));
    }
}
