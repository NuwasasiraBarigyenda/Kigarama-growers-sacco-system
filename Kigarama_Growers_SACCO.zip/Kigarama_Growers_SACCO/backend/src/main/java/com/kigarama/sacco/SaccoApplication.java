package com.kigarama.sacco;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Kigarama Growers SACCO - Agricultural SACCO Management System.
 * Handles coffee (kg, fluctuating global price) and matooke (small/medium/large bunch)
 * produce logging, member savings accounts, deposits/withdrawals, and role-based portals
 * for Super Admin, Admin, Cashier, Receptionist and Member.
 */
@SpringBootApplication
public class SaccoApplication {
    public static void main(String[] args) {
        SpringApplication.run(SaccoApplication.class, args);
    }
}
