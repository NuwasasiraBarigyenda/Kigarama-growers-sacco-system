package com.kigarama.sacco.service;

import com.kigarama.sacco.dto.CreateUserRequest;
import com.kigarama.sacco.dto.CreateUserResult;
import com.kigarama.sacco.model.*;
import com.kigarama.sacco.repository.AccountRepository;
import com.kigarama.sacco.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final AccountRepository accountRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final SecureRandom random = new SecureRandom();

    public UserService(UserRepository userRepository, AccountRepository accountRepository,
                        PasswordEncoder passwordEncoder, EmailService emailService) {
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    /**
     * Creates a new user account, enforcing the account hierarchy:
     * Super Admin can create Admins, Cashiers, Receptionists and Members.
     * Admin can create Cashiers, Receptionists and Members (not other Admins or Super Admins).
     * Emails the new user their login details (and SACCO PIN, if a Member) — this is the only
     * point the plaintext PIN ever exists outside the hashed database column, so it's also
     * returned to the caller once so it can be shown on screen as a fallback.
     */
    @Transactional
    public CreateUserResult createUser(CreateUserRequest request, Role creatorRole, String creatorUsername) {
        Role targetRole = Role.valueOf(request.getRole().trim().toUpperCase());

        if (creatorRole == Role.ADMIN && (targetRole == Role.ADMIN || targetRole == Role.SUPER_ADMIN)) {
            throw new IllegalArgumentException("Admins may only create Cashier, Receptionist or Member accounts.");
        }
        if (creatorRole != Role.SUPER_ADMIN && creatorRole != Role.ADMIN) {
            throw new IllegalArgumentException("You are not permitted to create user accounts.");
        }
        if (userRepository.existsByUsernameIgnoreCase(request.getUsername())) {
            throw new IllegalArgumentException("Username already exists.");
        }
        if (request.getEmail() == null || request.getEmail().isBlank()) {
            throw new IllegalArgumentException("Email is required (used for password reset and notifications).");
        }
        if (userRepository.existsByEmailIgnoreCase(request.getEmail().trim())) {
            throw new IllegalArgumentException("An account with that email already exists.");
        }

        User user = new User(
                request.getUsername().trim(),
                request.getEmail().trim(),
                passwordEncoder.encode(request.getPassword()),
                request.getFullName().trim(),
                request.getPhone(),
                targetRole,
                creatorUsername
        );
        user = userRepository.save(user);

        String plainPin = null;
        if (targetRole == Role.MEMBER) {
            plainPin = (request.getInitialPin() != null && !request.getInitialPin().isBlank())
                    ? request.getInitialPin().trim() : generateDefaultPin();
            String accountNumber = generateAccountNumber();
            Account account = new Account(user, accountNumber, passwordEncoder.encode(plainPin));
            accountRepository.save(account);
        }

        emailService.sendAccountCreatedEmail(user.getEmail(), user.getFullName(), user.getUsername(),
                request.getPassword(), plainPin, targetRole.name());

        return new CreateUserResult(user, plainPin);
    }

    private String generateDefaultPin() {
        return String.format("%04d", random.nextInt(10000));
    }

    private String generateAccountNumber() {
        String candidate;
        do {
            candidate = "KGS" + String.format("%06d", random.nextInt(1_000_000));
        } while (accountRepository.existsByAccountNumber(candidate));
        return candidate;
    }

    public List<User> listByRole(Role role) {
        return userRepository.findByRole(role);
    }

    public List<User> listAll() {
        return userRepository.findAll();
    }

    @Transactional
    public User setActive(Long userId, boolean active) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new IllegalArgumentException("User not found"));
        user.setActive(active);
        return userRepository.save(user);
    }
}
