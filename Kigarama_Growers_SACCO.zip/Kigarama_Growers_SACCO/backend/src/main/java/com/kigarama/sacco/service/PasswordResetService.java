package com.kigarama.sacco.service;

import com.kigarama.sacco.model.PasswordResetToken;
import com.kigarama.sacco.model.User;
import com.kigarama.sacco.repository.PasswordResetTokenRepository;
import com.kigarama.sacco.repository.UserRepository;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.security.SecureRandom;
import java.time.LocalDateTime;

@Service
public class PasswordResetService {

    private static final int CODE_EXPIRY_MINUTES = 15;

    private final UserRepository userRepository;
    private final PasswordResetTokenRepository tokenRepository;
    private final PasswordEncoder passwordEncoder;
    private final EmailService emailService;
    private final SecureRandom random = new SecureRandom();

    public PasswordResetService(UserRepository userRepository, PasswordResetTokenRepository tokenRepository,
                                 PasswordEncoder passwordEncoder, EmailService emailService) {
        this.userRepository = userRepository;
        this.tokenRepository = tokenRepository;
        this.passwordEncoder = passwordEncoder;
        this.emailService = emailService;
    }

    /**
     * Generates and emails a reset code if the email matches an account. Always completes
     * silently (no exception, no "not found" signal) when the email doesn't match anything —
     * this prevents the endpoint being used to discover which emails have accounts.
     */
    @Transactional
    public void requestReset(String email) {
        userRepository.findByEmailIgnoreCase(email.trim()).ifPresent(user -> {
            String code = String.format("%06d", random.nextInt(1_000_000));
            PasswordResetToken token = new PasswordResetToken(user, code, LocalDateTime.now().plusMinutes(CODE_EXPIRY_MINUTES));
            tokenRepository.save(token);
            emailService.sendPasswordResetCode(user.getEmail(), user.getFullName(), code);
        });
    }

    @Transactional
    public void resetPassword(String email, String code, String newPassword) {
        User user = userRepository.findByEmailIgnoreCase(email.trim())
                .orElseThrow(() -> new IllegalArgumentException("Invalid email or code."));

        PasswordResetToken token = tokenRepository.findValidCandidates(user.getId(), code.trim())
                .stream().findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Invalid or expired code."));

        if (token.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("This code has expired. Please request a new one.");
        }
        if (newPassword == null || newPassword.length() < 6) {
            throw new IllegalArgumentException("New password must be at least 6 characters.");
        }

        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);

        token.setUsed(true);
        tokenRepository.save(token);
    }
}
