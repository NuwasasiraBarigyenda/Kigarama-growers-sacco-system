package com.kigarama.sacco.dto;

import jakarta.validation.constraints.NotBlank;

public class CreateUserRequest {
    @NotBlank
    private String username;
    @NotBlank
    private String password;
    @NotBlank
    private String fullName;
    private String phone;
    private String email;
    @NotBlank
    private String role; // SUPER_ADMIN, ADMIN, CASHIER, RECEPTIONIST, MEMBER

    /** Required only when role = MEMBER; sets up their savings account PIN. */
    private String initialPin;

    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getFullName() { return fullName; }
    public void setFullName(String fullName) { this.fullName = fullName; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
    public String getInitialPin() { return initialPin; }
    public void setInitialPin(String initialPin) { this.initialPin = initialPin; }
}
