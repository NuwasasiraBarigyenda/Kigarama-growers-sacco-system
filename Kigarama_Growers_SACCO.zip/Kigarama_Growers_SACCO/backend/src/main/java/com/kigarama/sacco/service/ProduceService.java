package com.kigarama.sacco.service;

import com.kigarama.sacco.model.*;
import com.kigarama.sacco.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

@Service
public class ProduceService {

    private final CoffeePriceRepository coffeePriceRepository;
    private final MatookePriceRepository matookePriceRepository;
    private final CoffeeLogRepository coffeeLogRepository;
    private final MatookeLogRepository matookeLogRepository;
    private final UserRepository userRepository;
    private final AccountRepository accountRepository;
    private final AccountService accountService;

    public ProduceService(CoffeePriceRepository coffeePriceRepository, MatookePriceRepository matookePriceRepository,
                           CoffeeLogRepository coffeeLogRepository, MatookeLogRepository matookeLogRepository,
                           UserRepository userRepository, AccountRepository accountRepository,
                           AccountService accountService) {
        this.coffeePriceRepository = coffeePriceRepository;
        this.matookePriceRepository = matookePriceRepository;
        this.coffeeLogRepository = coffeeLogRepository;
        this.matookeLogRepository = matookeLogRepository;
        this.userRepository = userRepository;
        this.accountRepository = accountRepository;
        this.accountService = accountService;
    }

    // ---------------- Pricing ----------------

    public CoffeePrice getCurrentCoffeePrice() {
        return coffeePriceRepository.findFirstByOrderByEffectiveAtDesc()
                .orElseThrow(() -> new IllegalStateException("No coffee price has been set yet."));
    }

    public List<CoffeePrice> getCoffeePriceHistory() {
        return coffeePriceRepository.findTop30ByOrderByEffectiveAtDesc();
    }

    @Transactional
    public CoffeePrice updateCoffeePrice(BigDecimal pricePerKg, String setBy, String note) {
        if (pricePerKg == null || pricePerKg.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Coffee price must be greater than zero.");
        }
        return coffeePriceRepository.save(new CoffeePrice(pricePerKg, setBy, note));
    }

    public MatookePrice getCurrentMatookePrice(MatookeSize size) {
        return matookePriceRepository.findFirstBySizeOrderByEffectiveAtDesc(size)
                .orElseThrow(() -> new IllegalStateException("No price set for " + size + " matooke bunches yet."));
    }

    @Transactional
    public void updateMatookePrices(BigDecimal small, BigDecimal medium, BigDecimal large, String setBy) {
        if (small != null) matookePriceRepository.save(new MatookePrice(MatookeSize.SMALL, small, setBy));
        if (medium != null) matookePriceRepository.save(new MatookePrice(MatookeSize.MEDIUM, medium, setBy));
        if (large != null) matookePriceRepository.save(new MatookePrice(MatookeSize.LARGE, large, setBy));
    }

    // ---------------- Coffee intake ----------------

    @Transactional
    public CoffeeLog logCoffeeIntake(Long memberId, BigDecimal kilograms, String recordedBy) {
        if (kilograms == null || kilograms.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Kilograms must be greater than zero.");
        }
        User member = userRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found."));
        if (member.getRole() != Role.MEMBER) {
            throw new IllegalArgumentException("Produce can only be logged against a Member account.");
        }
        CoffeePrice price = getCurrentCoffeePrice();
        BigDecimal total = kilograms.multiply(price.getPricePerKg()).setScale(2, RoundingMode.HALF_UP);

        CoffeeLog log = new CoffeeLog();
        log.setMember(member);
        log.setKilograms(kilograms);
        log.setPricePerKgAtSale(price.getPricePerKg());
        log.setTotalValue(total);
        log.setRecordedBy(recordedBy);
        log = coffeeLogRepository.save(log);

        Account account = accountRepository.findByUserId(memberId)
                .orElseThrow(() -> new IllegalStateException("Member has no savings account."));
        accountService.credit(account, total, TransactionType.COFFEE_SALE_CREDIT, recordedBy,
                "Coffee intake: " + kilograms + " kg @ " + price.getPricePerKg() + "/kg");

        return log;
    }

    public List<CoffeeLog> coffeeHistoryFor(Long memberId) {
        return coffeeLogRepository.findByMemberIdOrderByRecordedAtDesc(memberId);
    }

    public List<CoffeeLog> recentCoffeeLogs() {
        return coffeeLogRepository.findTop50ByOrderByRecordedAtDesc();
    }

    // ---------------- Matooke intake ----------------

    @Transactional
    public MatookeLog logMatookeIntake(Long memberId, MatookeSize size, Integer quantity, String recordedBy) {
        if (quantity == null || quantity <= 0) {
            throw new IllegalArgumentException("Quantity must be greater than zero.");
        }
        User member = userRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found."));
        if (member.getRole() != Role.MEMBER) {
            throw new IllegalArgumentException("Produce can only be logged against a Member account.");
        }
        MatookePrice price = getCurrentMatookePrice(size);
        BigDecimal total = price.getPricePerBunch().multiply(BigDecimal.valueOf(quantity)).setScale(2, RoundingMode.HALF_UP);

        MatookeLog log = new MatookeLog();
        log.setMember(member);
        log.setSize(size);
        log.setQuantity(quantity);
        log.setPricePerBunchAtSale(price.getPricePerBunch());
        log.setTotalValue(total);
        log.setRecordedBy(recordedBy);
        log = matookeLogRepository.save(log);

        Account account = accountRepository.findByUserId(memberId)
                .orElseThrow(() -> new IllegalStateException("Member has no savings account."));
        accountService.credit(account, total, TransactionType.MATOOKE_SALE_CREDIT, recordedBy,
                "Matooke intake: " + quantity + " " + size + " bunch(es) @ " + price.getPricePerBunch() + " each");

        return log;
    }

    public List<MatookeLog> matookeHistoryFor(Long memberId) {
        return matookeLogRepository.findByMemberIdOrderByRecordedAtDesc(memberId);
    }

    public List<MatookeLog> recentMatookeLogs() {
        return matookeLogRepository.findTop50ByOrderByRecordedAtDesc();
    }
}
