package com.kigarama.sacco.service;

import com.kigarama.sacco.model.*;
import com.kigarama.sacco.repository.LoanRepository;
import com.kigarama.sacco.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class LoanService {

    private final LoanRepository loanRepository;
    private final UserRepository userRepository;
    private final AccountService accountService;

    public LoanService(LoanRepository loanRepository, UserRepository userRepository, AccountService accountService) {
        this.loanRepository = loanRepository;
        this.userRepository = userRepository;
        this.accountService = accountService;
    }

    @Transactional
    public Loan apply(Long memberId, BigDecimal amountRequested, String purpose) {
        if (amountRequested == null || amountRequested.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Loan amount must be greater than zero.");
        }
        if (purpose == null || purpose.isBlank()) {
            throw new IllegalArgumentException("Please state the purpose of the loan.");
        }
        User member = userRepository.findById(memberId)
                .orElseThrow(() -> new IllegalArgumentException("Member not found."));

        Loan loan = new Loan();
        loan.setMember(member);
        loan.setAmountRequested(amountRequested);
        loan.setPurpose(purpose.trim());
        loan.setStatus(LoanStatus.PENDING);
        return loanRepository.save(loan);
    }

    public List<Loan> myLoans(Long memberId) {
        return loanRepository.findByMemberIdOrderByAppliedAtDesc(memberId);
    }

    public List<Loan> allLoans() {
        return loanRepository.findAllOrderByAppliedAtDesc();
    }

    public List<Loan> pendingLoans() {
        return loanRepository.findByStatusOrderByAppliedAtDesc(LoanStatus.PENDING);
    }

    /** Manager (Admin/Super Admin) approves or rejects a pending application. Approval does not yet move money. */
    @Transactional
    public Loan decide(Long loanId, boolean approve, String notes, String decidedBy) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new IllegalArgumentException("Loan application not found."));
        if (loan.getStatus() != LoanStatus.PENDING) {
            throw new IllegalArgumentException("This loan application has already been decided.");
        }
        loan.setStatus(approve ? LoanStatus.APPROVED : LoanStatus.REJECTED);
        loan.setDecisionNotes(notes);
        loan.setDecidedBy(decidedBy);
        loan.setDecidedAt(LocalDateTime.now());
        return loanRepository.save(loan);
    }

    /** Cashier disburses an approved loan — credits the member's savings account with the funds. */
    @Transactional
    public Loan disburse(Long loanId, String disbursedBy) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new IllegalArgumentException("Loan application not found."));
        if (loan.getStatus() != LoanStatus.APPROVED) {
            throw new IllegalArgumentException("Only approved loans can be disbursed.");
        }
        Account account = accountService.getByUserId(loan.getMember().getId());
        accountService.credit(account, loan.getAmountRequested(), TransactionType.LOAN_DISBURSEMENT,
                disbursedBy, "Loan disbursement — " + loan.getPurpose());

        loan.setStatus(LoanStatus.DISBURSED);
        loan.setOutstandingBalance(loan.getAmountRequested());
        loan.setDisbursedBy(disbursedBy);
        loan.setDisbursedAt(LocalDateTime.now());
        loan.setAccount(account);
        return loanRepository.save(loan);
    }

    /** Member repays part or all of an outstanding loan from their own savings balance. */
    @Transactional
    public Loan repay(Long loanId, Long memberId, BigDecimal amount) {
        Loan loan = loanRepository.findById(loanId)
                .orElseThrow(() -> new IllegalArgumentException("Loan not found."));
        if (!loan.getMember().getId().equals(memberId)) {
            throw new SecurityException("You may only repay your own loans.");
        }
        if (loan.getStatus() != LoanStatus.DISBURSED) {
            throw new IllegalArgumentException("This loan is not currently active.");
        }
        if (amount == null || amount.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("Repayment amount must be greater than zero.");
        }
        if (amount.compareTo(loan.getOutstandingBalance()) > 0) {
            throw new IllegalArgumentException("Repayment cannot exceed the outstanding balance of "
                    + loan.getOutstandingBalance());
        }

        Account account = accountService.getByUserId(memberId);
        accountService.debit(account.getId(), amount, TransactionType.LOAN_REPAYMENT, "member (self)",
                "Loan repayment — " + loan.getPurpose());

        loan.setOutstandingBalance(loan.getOutstandingBalance().subtract(amount));
        if (loan.getOutstandingBalance().compareTo(BigDecimal.ZERO) <= 0) {
            loan.setStatus(LoanStatus.CLOSED);
        }
        return loanRepository.save(loan);
    }
}
