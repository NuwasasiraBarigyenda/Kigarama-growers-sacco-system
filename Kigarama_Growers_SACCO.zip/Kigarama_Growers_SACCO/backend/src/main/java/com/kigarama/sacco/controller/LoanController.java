package com.kigarama.sacco.controller;

import com.kigarama.sacco.dto.LoanApplicationRequest;
import com.kigarama.sacco.dto.LoanDecisionRequest;
import com.kigarama.sacco.security.CustomUserDetails;
import com.kigarama.sacco.service.LoanService;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.Map;

@RestController
@RequestMapping("/api/loans")
public class LoanController {

    private final LoanService loanService;

    public LoanController(LoanService loanService) {
        this.loanService = loanService;
    }

    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/apply")
    public ResponseEntity<?> apply(@RequestBody LoanApplicationRequest request,
                                    @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            return ResponseEntity.ok(loanService.apply(principal.getId(), request.getAmountRequested(), request.getPurpose()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasRole('MEMBER')")
    @GetMapping("/my")
    public ResponseEntity<?> myLoans(@AuthenticationPrincipal CustomUserDetails principal) {
        return ResponseEntity.ok(loanService.myLoans(principal.getId()));
    }

    @PreAuthorize("hasRole('MEMBER')")
    @PostMapping("/{id}/repay")
    public ResponseEntity<?> repay(@PathVariable Long id, @RequestBody Map<String, Object> body,
                                    @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            BigDecimal amount = new BigDecimal(String.valueOf(body.get("amount")));
            return ResponseEntity.ok(loanService.repay(id, principal.getId(), amount));
        } catch (SecurityException e) {
            return ResponseEntity.status(403).body(Map.of("error", e.getMessage()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @GetMapping
    public ResponseEntity<?> allLoans(@RequestParam(required = false) Boolean pendingOnly) {
        return ResponseEntity.ok(Boolean.TRUE.equals(pendingOnly) ? loanService.pendingLoans() : loanService.allLoans());
    }

    /** The "manager" decision step — Admin/Super Admin approve or reject a pending application. */
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN')")
    @PutMapping("/{id}/decision")
    public ResponseEntity<?> decide(@PathVariable Long id, @RequestBody LoanDecisionRequest request,
                                     @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            return ResponseEntity.ok(loanService.decide(id, request.isApprove(), request.getNotes(), principal.getUsername()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    /** Cashiers hand over the approved funds. */
    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @GetMapping("/approved")
    public ResponseEntity<?> approvedLoans() {
        return ResponseEntity.ok(loanService.allLoans().stream()
                .filter(l -> l.getStatus().name().equals("APPROVED")).toList());
    }

    @PreAuthorize("hasAnyRole('SUPER_ADMIN','ADMIN','CASHIER')")
    @PostMapping("/{id}/disburse")
    public ResponseEntity<?> disburse(@PathVariable Long id, @AuthenticationPrincipal CustomUserDetails principal) {
        try {
            return ResponseEntity.ok(loanService.disburse(id, principal.getUsername()));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }
}
