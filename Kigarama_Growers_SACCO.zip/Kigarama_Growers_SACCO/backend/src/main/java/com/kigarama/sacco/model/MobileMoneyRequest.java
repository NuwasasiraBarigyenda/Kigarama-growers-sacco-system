package com.kigarama.sacco.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * A member-submitted mobile money deposit request. Since this system does not integrate with a
 * live telecom payment gateway, members submit the mobile money transaction details (provider,
 * phone number, amount, and the reference/confirmation code they received from MTN/Airtel), and
 * a Cashier or Admin verifies it against the actual mobile money statement before approving —
 * at which point the funds are credited to the member's SACCO savings account.
 */
@Entity
@Table(name = "mobile_money_requests")
public class MobileMoneyRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", nullable = false)
    private User member;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MobileMoneyProvider provider;

    @Column(nullable = false, length = 20)
    private String phoneNumber;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal amount;

    /** The confirmation/transaction code the member received via SMS from MTN/Airtel. */
    @Column(length = 60)
    private String reference;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private MobileMoneyStatus status = MobileMoneyStatus.PENDING;

    @Column(nullable = false)
    private LocalDateTime requestedAt = LocalDateTime.now();

    private String decidedBy;
    private LocalDateTime decidedAt;

    @Column(length = 255)
    private String decisionNotes;

    public MobileMoneyRequest() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getMember() { return member; }
    public void setMember(User member) { this.member = member; }

    public MobileMoneyProvider getProvider() { return provider; }
    public void setProvider(MobileMoneyProvider provider) { this.provider = provider; }

    public String getPhoneNumber() { return phoneNumber; }
    public void setPhoneNumber(String phoneNumber) { this.phoneNumber = phoneNumber; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public MobileMoneyStatus getStatus() { return status; }
    public void setStatus(MobileMoneyStatus status) { this.status = status; }

    public LocalDateTime getRequestedAt() { return requestedAt; }
    public void setRequestedAt(LocalDateTime requestedAt) { this.requestedAt = requestedAt; }

    public String getDecidedBy() { return decidedBy; }
    public void setDecidedBy(String decidedBy) { this.decidedBy = decidedBy; }

    public LocalDateTime getDecidedAt() { return decidedAt; }
    public void setDecidedAt(LocalDateTime decidedAt) { this.decidedAt = decidedAt; }

    public String getDecisionNotes() { return decisionNotes; }
    public void setDecisionNotes(String decisionNotes) { this.decisionNotes = decisionNotes; }
}
