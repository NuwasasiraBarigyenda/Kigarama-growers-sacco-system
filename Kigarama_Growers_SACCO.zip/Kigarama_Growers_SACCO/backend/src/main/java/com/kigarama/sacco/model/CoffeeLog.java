package com.kigarama.sacco.model;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "coffee_logs")
public class CoffeeLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "member_id", nullable = false)
    private User member;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal kilograms;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal pricePerKgAtSale;

    @Column(nullable = false, precision = 14, scale = 2)
    private BigDecimal totalValue;

    @Column(length = 60)
    private String recordedBy;

    @Column(nullable = false)
    private LocalDateTime recordedAt = LocalDateTime.now();

    /** Whether proceeds were credited to the member's savings account. */
    @Column(nullable = false)
    private boolean creditedToAccount = true;

    public CoffeeLog() {}

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public User getMember() { return member; }
    public void setMember(User member) { this.member = member; }

    public BigDecimal getKilograms() { return kilograms; }
    public void setKilograms(BigDecimal kilograms) { this.kilograms = kilograms; }

    public BigDecimal getPricePerKgAtSale() { return pricePerKgAtSale; }
    public void setPricePerKgAtSale(BigDecimal pricePerKgAtSale) { this.pricePerKgAtSale = pricePerKgAtSale; }

    public BigDecimal getTotalValue() { return totalValue; }
    public void setTotalValue(BigDecimal totalValue) { this.totalValue = totalValue; }

    public String getRecordedBy() { return recordedBy; }
    public void setRecordedBy(String recordedBy) { this.recordedBy = recordedBy; }

    public LocalDateTime getRecordedAt() { return recordedAt; }
    public void setRecordedAt(LocalDateTime recordedAt) { this.recordedAt = recordedAt; }

    public boolean isCreditedToAccount() { return creditedToAccount; }
    public void setCreditedToAccount(boolean creditedToAccount) { this.creditedToAccount = creditedToAccount; }
}
