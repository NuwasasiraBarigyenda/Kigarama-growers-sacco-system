package com.kigarama.sacco.repository;

import com.kigarama.sacco.model.ChatMessage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ChatMessageRepository extends JpaRepository<ChatMessage, Long> {

    @Query("select m from ChatMessage m join fetch m.sender join fetch m.receiver where " +
        "(m.sender.id = :userA and m.receiver.id = :userB) or " +
        "(m.sender.id = :userB and m.receiver.id = :userA) " +
        "order by m.timestamp asc")
    List<ChatMessage> findConversation(Long userA, Long userB);

    List<ChatMessage> findByReceiverIdAndIsReadFalse(Long receiverId);

    long countByReceiverIdAndIsReadFalse(Long receiverId);

    @Query("select m from ChatMessage m join fetch m.sender where m.receiver.id = :receiverId and m.isRead = false " +
        "order by m.timestamp desc")
    List<ChatMessage> findUnreadWithSender(Long receiverId);

    @Query("select distinct case when m.sender.id = :userId then m.receiver.id else m.sender.id end " +
        "from ChatMessage m where m.sender.id = :userId or m.receiver.id = :userId")
    List<Long> findConversationPartnerIds(Long userId);
}
