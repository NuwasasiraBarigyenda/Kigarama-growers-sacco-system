package com.kigarama.sacco.service;

import com.kigarama.sacco.model.ChatMessage;
import com.kigarama.sacco.model.User;
import com.kigarama.sacco.repository.ChatMessageRepository;
import com.kigarama.sacco.repository.UserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Chat is open to everyone in the system — any account can message any other account, and each
 * person picks who to talk to from a directory of every other user (see ChatController.contacts).
 * The only rule enforced here is that nobody can message themselves.
 */
@Service
public class ChatService {

    private final ChatMessageRepository chatMessageRepository;
    private final UserRepository userRepository;

    public ChatService(ChatMessageRepository chatMessageRepository, UserRepository userRepository) {
        this.chatMessageRepository = chatMessageRepository;
        this.userRepository = userRepository;
    }

    @Transactional
    public ChatMessage sendMessage(Long senderId, Long receiverId, String text, String attachmentUrl, String attachmentName) {
        if (senderId.equals(receiverId)) {
            throw new IllegalArgumentException("You can't send a message to yourself.");
        }
        User sender = userRepository.findById(senderId)
                .orElseThrow(() -> new IllegalArgumentException("Sender not found."));
        User receiver = userRepository.findById(receiverId)
                .orElseThrow(() -> new IllegalArgumentException("Recipient not found."));
        if (!receiver.isActive()) {
            throw new IllegalArgumentException("That account has been disabled and can't receive messages.");
        }

        ChatMessage message = new ChatMessage();
        message.setSender(sender);
        message.setReceiver(receiver);
        message.setMessage(text != null ? text : "");
        message.setAttachmentUrl(attachmentUrl);
        message.setAttachmentName(attachmentName);
        return chatMessageRepository.save(message);
    }

    public List<ChatMessage> conversation(Long userA, Long userB) {
        return chatMessageRepository.findConversation(userA, userB);
    }

    public List<Long> conversationPartners(Long userId) {
        return chatMessageRepository.findConversationPartnerIds(userId);
    }

    /** Maps senderId -> unread count, so the contact list can show a badge per person. */
    public java.util.Map<Long, Long> unreadCountsBySender(Long readerId) {
        return chatMessageRepository.findByReceiverIdAndIsReadFalse(readerId).stream()
                .collect(java.util.stream.Collectors.groupingBy(m -> m.getSender().getId(), java.util.stream.Collectors.counting()));
    }

    @Transactional
    public void markConversationRead(Long readerId, Long otherUserId) {
        List<ChatMessage> unread = chatMessageRepository.findByReceiverIdAndIsReadFalse(readerId);
        for (ChatMessage m : unread) {
            if (m.getSender().getId().equals(otherUserId)) {
                m.setRead(true);
            }
        }
        chatMessageRepository.saveAll(unread);
    }
}
