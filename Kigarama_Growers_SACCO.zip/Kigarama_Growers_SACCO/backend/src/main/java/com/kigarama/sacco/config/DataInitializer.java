package com.kigarama.sacco.config;

import com.kigarama.sacco.model.*;
import com.kigarama.sacco.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

/**
 * Bootstraps the database on first launch:
 *  - Creates the default Super Admin account (full privileges) if none exists.
 *  - Creates a default Receptionist so the member chat portal works out of the box.
 *  - Seeds an initial coffee price and matooke bunch prices so dashboards aren't empty.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private static final Logger log = LoggerFactory.getLogger(DataInitializer.class);

    private final UserRepository userRepository;
    private final CoffeePriceRepository coffeePriceRepository;
    private final MatookePriceRepository matookePriceRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${sacco.bootstrap.superadmin.username}")
    private String superAdminUsername;
    @Value("${sacco.bootstrap.superadmin.password}")
    private String superAdminPassword;
    @Value("${sacco.bootstrap.superadmin.fullname}")
    private String superAdminFullName;
    @Value("${sacco.bootstrap.superadmin.email:superadmin@kigaramasacco.co.ug}")
    private String superAdminEmail;

    @Value("${sacco.bootstrap.receptionist.username}")
    private String receptionistUsername;
    @Value("${sacco.bootstrap.receptionist.password}")
    private String receptionistPassword;
    @Value("${sacco.bootstrap.receptionist.fullname}")
    private String receptionistFullName;
    @Value("${sacco.bootstrap.receptionist.email:reception@kigaramasacco.co.ug}")
    private String receptionistEmail;

    public DataInitializer(UserRepository userRepository,
                            CoffeePriceRepository coffeePriceRepository,
                            MatookePriceRepository matookePriceRepository,
                            PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.coffeePriceRepository = coffeePriceRepository;
        this.matookePriceRepository = matookePriceRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public void run(String... args) {
        if (userRepository.countByRole(Role.SUPER_ADMIN) == 0) {
            User superAdmin = new User(
                    superAdminUsername,
                    superAdminEmail,
                    passwordEncoder.encode(superAdminPassword),
                    superAdminFullName,
                    "0700000000",
                    Role.SUPER_ADMIN,
                    "SYSTEM"
            );
            userRepository.save(superAdmin);
            log.info("=================================================================");
            log.info(" Kigarama Growers SACCO — default Super Admin account created");
            log.info(" Username: {}", superAdminUsername);
            log.info(" Password: {}", superAdminPassword);
            log.info(" Email:    {}", superAdminEmail);
            log.info(" >>> Please log in and change this password immediately. <<<");
            log.info("=================================================================");
        }

        if (!userRepository.existsByUsernameIgnoreCase(receptionistUsername)) {
            User receptionist = new User(
                    receptionistUsername,
                    receptionistEmail,
                    passwordEncoder.encode(receptionistPassword),
                    receptionistFullName,
                    "0700000001",
                    Role.RECEPTIONIST,
                    "SYSTEM"
            );
            userRepository.save(receptionist);
            log.info("Default receptionist account created (username: {})", receptionistUsername);
        }

        if (coffeePriceRepository.findFirstByOrderByEffectiveAtDesc().isEmpty()) {
            coffeePriceRepository.save(new CoffeePrice(new BigDecimal("9500.00"), "SYSTEM", "Initial seeded world-market price"));
            log.info("Seeded initial coffee price: UGX 9,500 / kg");
        }

        if (matookePriceRepository.findFirstBySizeOrderByEffectiveAtDesc(MatookeSize.SMALL).isEmpty()) {
            matookePriceRepository.save(new MatookePrice(MatookeSize.SMALL, new BigDecimal("8000.00"), "SYSTEM"));
            matookePriceRepository.save(new MatookePrice(MatookeSize.MEDIUM, new BigDecimal("12000.00"), "SYSTEM"));
            matookePriceRepository.save(new MatookePrice(MatookeSize.LARGE, new BigDecimal("18000.00"), "SYSTEM"));
            log.info("Seeded initial matooke bunch prices (Small/Medium/Large)");
        }
    }
}
