package com.kigarama.sacco.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

/**
 * Sends transactional emails (currently just password-reset codes). If SMTP isn't configured
 * (sacco.mail.enabled=false, the default until you fill in real credentials), the code is logged
 * to the console instead of emailed — so the reset flow is still testable in local development
 * without a mail server.
 */
@Service
public class EmailService {

    private static final Logger log = LoggerFactory.getLogger(EmailService.class);

    private final JavaMailSender mailSender;

    @Value("${sacco.mail.enabled:false}")
    private boolean mailEnabled;

    @Value("${spring.mail.username:no-reply@kigaramasacco.co.ug}")
    private String fromAddress;

    public EmailService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendPasswordResetCode(String toEmail, String fullName, String code) {
        String subject = "Kigarama Growers SACCO — Password Reset Code";
        String body = "Hello " + fullName + ",\n\n"
                + "You requested to reset your Kigarama Growers SACCO account password.\n\n"
                + "Your reset code is: " + code + "\n\n"
                + "This code expires in 15 minutes. If you did not request this, you can safely ignore this email.\n\n"
                + "— Kigarama Growers SACCO";
        sendOrLog(toEmail, subject, body, "Password reset code for " + toEmail + ": " + code);
    }

    /**
     * Sent automatically the moment an account is created, so the new user actually finds out
     * their login details — and, for Members, their secret SACCO PIN — without the admin who
     * created the account having to relay it another way.
     */
    public void sendAccountCreatedEmail(String toEmail, String fullName, String username,
                                         String temporaryPassword, String pin, String role) {
        String subject = "Welcome to Kigarama Growers SACCO — Your Account Details";
        StringBuilder body = new StringBuilder();
        body.append("Hello ").append(fullName).append(",\n\n")
            .append("An account has been created for you at Kigarama Growers SACCO.\n\n")
            .append("Username: ").append(username).append("\n")
            .append("Temporary password: ").append(temporaryPassword).append("\n");
        if (pin != null) {
            body.append("Your secret SACCO PIN (needed to view your balance): ").append(pin).append("\n");
        }
        body.append("\nPlease log in and change your password as soon as possible");
        if (pin != null) {
            body.append(", and consider changing your PIN too (My Profile once logged in)");
        }
        body.append(".\n\n— Kigarama Growers SACCO");

        String logSummary = "Welcome email for " + username + " (" + role + "): password=" + temporaryPassword
                + (pin != null ? ", PIN=" + pin : "");
        sendOrLog(toEmail, subject, body.toString(), logSummary);
    }

    private void sendOrLog(String toEmail, String subject, String body, String logSummary) {
        if (!mailEnabled) {
            // Dev-mode fallback: no SMTP configured yet, so surface the content in the server log
            // instead of failing the whole flow. Configure spring.mail.* and set
            // sacco.mail.enabled=true in application.properties to send real emails.
            log.warn("=================================================================");
            log.warn(" [DEV MODE — email sending disabled] {}", logSummary);
            log.warn(" Set sacco.mail.enabled=true and configure spring.mail.* to send real emails.");
            log.warn("=================================================================");
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromAddress);
            message.setTo(toEmail);
            message.setSubject(subject);
            message.setText(body);
            mailSender.send(message);
        } catch (Exception e) {
            log.error("Failed to send email to {}: {}", toEmail, e.getMessage());
            log.warn("Falling back to console — {}", logSummary);
        }
    }
}
