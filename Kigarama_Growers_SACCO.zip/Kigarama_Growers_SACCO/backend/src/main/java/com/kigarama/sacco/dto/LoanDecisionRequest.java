package com.kigarama.sacco.dto;

public class LoanDecisionRequest {
    private boolean approve;
    private String notes;

    public boolean isApprove() { return approve; }
    public void setApprove(boolean approve) { this.approve = approve; }
    public String getNotes() { return notes; }
    public void setNotes(String notes) { this.notes = notes; }
}
