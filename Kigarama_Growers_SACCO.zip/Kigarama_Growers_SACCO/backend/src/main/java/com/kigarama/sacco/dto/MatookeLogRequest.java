package com.kigarama.sacco.dto;

import com.kigarama.sacco.model.MatookeSize;

public class MatookeLogRequest {
    private Long memberId;
    private String memberUsername;
    private MatookeSize size;
    private Integer quantity;

    public Long getMemberId() { return memberId; }
    public void setMemberId(Long memberId) { this.memberId = memberId; }
    public String getMemberUsername() { return memberUsername; }
    public void setMemberUsername(String memberUsername) { this.memberUsername = memberUsername; }
    public MatookeSize getSize() { return size; }
    public void setSize(MatookeSize size) { this.size = size; }
    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }
}
