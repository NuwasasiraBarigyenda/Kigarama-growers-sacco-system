@echo off
REM Kigarama Growers SACCO — quick start (Windows)
REM Builds and runs the backend, which also serves the frontend at http://localhost:8080
cd /d "%~dp0backend"
echo Starting Kigarama Growers SACCO backend on http://localhost:8080 ...
mvnw.cmd spring-boot:run
