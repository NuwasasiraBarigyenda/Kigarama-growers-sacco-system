#!/bin/sh
# Kigarama Growers SACCO — quick start (Linux/Mac)
# Builds and runs the backend, which also serves the frontend at http://localhost:8080
set -e
cd "$(dirname "$0")/backend"
echo "Starting Kigarama Growers SACCO backend on http://localhost:8080 ..."
./mvnw spring-boot:run
